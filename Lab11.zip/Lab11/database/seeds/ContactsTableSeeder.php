<?php

use Illuminate\Database\Seeder;

class ContactsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('contacts')->insert([
            ['name'=>'Harry', 'phone'=>'021 678 987'],
            ['name'=>'Ron', 'phone'=>'021 678 333'],
            ['name'=>'Hermione', 'phone'=>'021 678 111']
        ]);
    }
}
